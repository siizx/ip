#include <iostream>

using std::cout;
using std::endl;
using std::cin;

int main () {

	int input = 0;
	int origin = input;
	int div = 2;
	int potenza = 0;
	int counter = 2;
	cout << "Inserisci un numero intero maggiore di 1: ";
	cin >> input;
	cout << endl;

	while ((input%div==0 || input%div<1) && input !=1) {
		input = input/div;
		potenza = potenza+1;
		if (input%div != 0) {
			cout << div << "^" << potenza;
			if (input%div!=0 && input !=1) cout << " * ";
			else cout << endl;
			counter = counter+1;
			div=div+1;
			if (div%2==0 && div != 2) div= div +1;
			potenza = 0;
			while (div%2==0 && div!=2) div = div/2;
			if ((input%div!=0 || input%div<1) && input !=1) div +1;
		}

	}
    return 0;
}

