#include "ll.h"

void addhead(ll &s, char & c)
{
}

bool removehead(ll &s, char & c)
{
}

int size(ll s)
{
}
