#include <string>
#include <vector>

std::vector<std::string> substrings(std::string s, char opening, char closing);
int match(std::vector<std::string> kwlist1, std::vector<std::string> kwlist2);
int nomatch(std::vector<std::string> kwlist1, std::vector<std::string> kwlist2);
