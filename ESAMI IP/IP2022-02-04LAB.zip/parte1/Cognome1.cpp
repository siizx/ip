#include "keywords.h"

using namespace std;

vector<string> substrings(string s, char opening, char closing)
{
  
}

int match(vector<string> kwlist1, vector<string> kwlist2)
{
  
}

int nomatch(vector<string> kwlist1, vector<string> kwlist2)
{
  
}
