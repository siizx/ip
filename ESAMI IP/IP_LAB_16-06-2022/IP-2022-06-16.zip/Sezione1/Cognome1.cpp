#include "hist.h"


// Aggiunge
void add(Hist & h, const int v)
{
}

// ordina
void sort(Hist & h)
{
}

// Cerca, restituisce conteggio
int count(const Hist & h, int v)
{
}
