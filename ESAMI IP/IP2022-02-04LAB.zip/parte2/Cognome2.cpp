#include "nomi.h"


// restituisce una lista di conteggi nomi in cui ogni nome compare
// solo una volta, con annotato il numero di volte in cui appare
// nella lista in ingresso (campo "frequenza")
ListaConteggiNomi unique(ListaNomi l)
{
  return nullptr;
}
